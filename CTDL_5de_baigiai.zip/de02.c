/*
 * DE SO 02 - Cau truc du lieu - HK2 2024-2025
 * Cau 1: Cay tong quat - he thong thu muc/tep tin
 * Cau 2: Do thi vo huong (danh sach ke) - mang may tinh
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===================== CAU 1 ===================== */

typedef struct TreeNode {
    char name[100];
    int size; /* MB, 0 neu la thu muc */
    struct TreeNode *firstChild;
    struct TreeNode *nextSibling;
} TreeNode;

TreeNode* newNode(const char *name, int size) {
    TreeNode *n = (TreeNode*)malloc(sizeof(TreeNode));
    strcpy(n->name, name);
    n->size = size;
    n->firstChild = n->nextSibling = NULL;
    return n;
}

/* tim node theo ten (duyet toan cay) - dung chung cho cac cau b,c */
TreeNode* findNode(TreeNode *root, const char *name) {
    if (root == NULL) return NULL;
    if (strcmp(root->name, name) == 0) return root;
    TreeNode *found = findNode(root->firstChild, name);
    if (found) return found;
    return findNode(root->nextSibling, name);
}

/* b) them tep tin/thu muc lam con cua node ten x */
int addChild(TreeNode *root, const char *parentName, const char *name, int size) {
    TreeNode *parent = findNode(root, parentName);
    if (parent == NULL) return 0;
    TreeNode *child = newNode(name, size);
    if (parent->firstChild == NULL) {
        parent->firstChild = child;
    } else {
        TreeNode *cur = parent->firstChild;
        while (cur->nextSibling) cur = cur->nextSibling;
        cur->nextSibling = child;
    }
    return 1;
}

/* c) kiem tra ten x co ton tai trong cay */
int existsNode(TreeNode *root, const char *name) {
    return findNode(root, name) != NULL;
}

/* d) liet ke tat ca tep tin (size > 0, khong tinh thu muc) co kich thuoc LON NHAT */
void findMaxSize(TreeNode *root, int *maxSize) {
    if (root == NULL) return;
    if (root->size > *maxSize) *maxSize = root->size;
    findMaxSize(root->firstChild, maxSize);
    findMaxSize(root->nextSibling, maxSize);
}
void printMaxFiles(TreeNode *root, int maxSize) {
    if (root == NULL) return;
    if (root->size == maxSize)
        printf("  - %s (%d MB)\n", root->name, root->size);
    printMaxFiles(root->firstChild, maxSize);
    printMaxFiles(root->nextSibling, maxSize);
}
void listLargestFiles(TreeNode *root) {
    int maxSize = 0;
    findMaxSize(root, &maxSize);
    if (maxSize == 0) { printf("  (Khong co tep tin nao)\n"); return; }
    printMaxFiles(root, maxSize);
}

void freeTree(TreeNode *root) {
    if (!root) return;
    freeTree(root->firstChild);
    freeTree(root->nextSibling);
    free(root);
}

/* ===================== CAU 2 ===================== */
#define MAXN 100

typedef struct {
    int n;
    int adj[MAXN][MAXN];
    int deg[MAXN];
} Graph;

void initGraph(Graph *g, int n) {
    g->n = n;
    memset(g->adj, 0, sizeof(g->adj));
    memset(g->deg, 0, sizeof(g->deg));
}
void addEdge(Graph *g, int u, int v) {
    if (!g->adj[u][v]) {
        g->adj[u][v] = g->adj[v][u] = 1;
        g->deg[u]++; g->deg[v]++;
    }
}
/* b) may tinh x noi truc tiep voi nhung may tinh nao */
void directNeighbors(Graph *g, int k) {
    printf("May tinh %d noi truc tiep voi %d may: ", k, g->deg[k]);
    for (int i = 0; i < g->n; i++) if (g->adj[k][i]) printf("%d ", i);
    printf("\n");
}
int bfsPath(Graph *g, int x, int y, int path[]) {
    int prev[MAXN], visited[MAXN] = {0};
    int queue[MAXN], front = 0, rear = 0;
    for (int i = 0; i < g->n; i++) prev[i] = -1;
    queue[rear++] = x; visited[x] = 1;
    while (front < rear) {
        int u = queue[front++];
        if (u == y) break;
        for (int v = 0; v < g->n; v++)
            if (g->adj[u][v] && !visited[v]) { visited[v]=1; prev[v]=u; queue[rear++]=v; }
    }
    if (!visited[y]) return -1;
    int len = 0, cur = y, tmp[MAXN];
    while (cur != -1) { tmp[len++] = cur; cur = prev[cur]; }
    for (int i = 0; i < len; i++) path[i] = tmp[len-1-i];
    return len;
}
/* c) may x noi voi may y phai qua it nhat bao nhieu may trung gian, la may nao */
void reportConnection(Graph *g, int x, int y) {
    int path[MAXN];
    int len = bfsPath(g, x, y, path);
    if (len == -1) { printf("May %d va may %d khong ket noi.\n", x, y); return; }
    if (g->adj[x][y]) printf("May %d va may %d noi TRUC TIEP.\n", x, y);
    else {
        printf("May %d va may %d phai qua %d may trung gian: ", x, y, len-2);
        for (int i = 1; i < len-1; i++) printf("%d ", path[i]);
        printf("\n");
    }
}
/* d) so cum ket noi, moi cum gom nhung may tinh nao */
void connectedComponents(Graph *g) {
    int visited[MAXN] = {0}, comp = 0;
    for (int s = 0; s < g->n; s++) {
        if (visited[s]) continue;
        comp++;
        int queue[MAXN], front=0, rear=0;
        queue[rear++]=s; visited[s]=1;
        printf("Cum %d: %d ", comp, s);
        while (front<rear) {
            int u=queue[front++];
            for (int v=0; v<g->n; v++)
                if (g->adj[u][v] && !visited[v]) { visited[v]=1; printf("%d ",v); queue[rear++]=v; }
        }
        printf("\n");
    }
    printf("Tong so cum ket noi: %d\n", comp);
}

/* ===================== MAIN ===================== */
int main() {
    printf("========== CAU 1: CAY THU MUC ==========\n");
    /*
       May Tinh(0)
        |- Tai lieu(0)
        |     |- CV.pdf(2)
        |- Anh(0)
              |- Dulich.jpg(5)
    */
    TreeNode *root = newNode("May Tinh", 0);
    TreeNode *taiLieu = newNode("Tai lieu", 0);
    TreeNode *anh = newNode("Anh", 0);
    root->firstChild = taiLieu;
    taiLieu->nextSibling = anh;
    taiLieu->firstChild = newNode("CV.pdf", 2);
    anh->firstChild = newNode("Dulich.jpg", 5);

    /* Them 1 tep cds.docx (5MB) la con cua thu muc Tai lieu */
    addChild(root, "Tai lieu", "cds.docx", 5);

    char qName[100];
    printf("Nhap ten tep tin/thu muc can kiem tra: ");
    fgets(qName, sizeof(qName), stdin);
    qName[strcspn(qName, "\n")] = 0;
    if (existsNode(root, qName))
        printf("=> \"%s\" CO trong cay.\n", qName);
    else
        printf("=> \"%s\" KHONG co trong cay.\n", qName);

    printf("Cac tep tin co kich thuoc lon nhat:\n");
    listLargestFiles(root);

    freeTree(root);

    printf("\n========== CAU 2: MANG MAY TINH ==========\n");
    Graph g;
    initGraph(&g, 7);
    /* 0:[1,2,5] 1:[0,3,6] 2:[0,4,6] 3:[1,5] 4:[2,6] 5:[0,3] 6:[1,2,4] */
    addEdge(&g,0,1); addEdge(&g,0,2); addEdge(&g,0,5);
    addEdge(&g,1,3); addEdge(&g,1,6);
    addEdge(&g,2,4); addEdge(&g,2,6);
    addEdge(&g,3,5);
    addEdge(&g,4,6);

    directNeighbors(&g, 3);
    reportConnection(&g, 1, 5);
    connectedComponents(&g);

    return 0;
}
