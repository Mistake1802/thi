/*
 * DE THI CUOI KY - HOC KY 1 - NAM HOC 2023-2024
 * Cau 1: BST so nguyen - tong cac so chan, cap cua 1 so trong cay
 * Cau 2: Do thi CO HUONG (danh sach ke) - quan he "biet nha"
 *
 * *** LUU Y QUAN TRONG VE CAU 2 ***
 * Anh chup do thi bi nghieng/mo nen minh khong doc chac chan duoc
 * chieu cua tat ca mui ten va so luong sinh vien (n) chinh xac.
 * Minh da PHUC DUNG TAM danh sach canh trong main() (co ghi chu ro),
 * cac ham xu ly (b, c) da dung logic va se chay dung voi bat ky do
 * thi nao ban nhap dung. Ban chi can doi chieu lai voi de goc va
 * sua lai cac dong addDirectedEdge(...) cho khop la duoc.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===================== CAU 1 ===================== */
typedef struct BSTNode {
    int key;
    struct BSTNode *left, *right;
} BSTNode;

BSTNode* newIntNode(int key) {
    BSTNode *n = (BSTNode*)malloc(sizeof(BSTNode));
    n->key = key;
    n->left = n->right = NULL;
    return n;
}

/* b) tong cac so chan trong cay */
int sumEven(BSTNode *root) {
    if (!root) return 0;
    int s = sumEven(root->left) + sumEven(root->right);
    if (root->key % 2 == 0) s += root->key;
    return s;
}

/* c) cap (level) cua so x trong cay.
   Quy uoc: goc la cap 1; neu khong co trong cay thi cap la 0. */
int levelOf(BSTNode *root, int x, int level) {
    if (!root) return 0; /* khong tim thay */
    if (root->key == x) return level;
    if (x < root->key) return levelOf(root->left, x, level + 1);
    else return levelOf(root->right, x, level + 1);
}

void freeIntTree(BSTNode *root) {
    if (!root) return;
    freeIntTree(root->left);
    freeIntTree(root->right);
    free(root);
}

/* ===================== CAU 2 ===================== */
#define MAXN 100
typedef struct {
    int n;
    int adj[MAXN][MAXN]; /* adj[u][v]=1 neu u biet nha v TRUC TIEP (co huong) */
} DiGraph;

void initDiGraph(DiGraph *g, int n) { g->n = n; memset(g->adj, 0, sizeof(g->adj)); }
void addDirectedEdge(DiGraph *g, int u, int v) { g->adj[u][v] = 1; }

/* b) liet ke nhung sinh vien ma sinh vien k biet nha TRUC TIEP */
void directKnown(DiGraph *g, int k) {
    printf("Sinh vien %d biet nha truc tiep: ", k);
    int found = 0;
    for (int i = 0; i < g->n; i++)
        if (g->adj[k][i]) { printf("%d ", i); found = 1; }
    if (!found) printf("(khong co)");
    printf("\n");
}

/* c) BFS tren do thi co huong: x co biet duoc nha y khong (truc tiep hoac qua trung gian)?
   Neu co, tra ve so dinh tren duong di (bao gom x, y) */
int bfsDirected(DiGraph *g, int x, int y, int path[]) {
    int prev[MAXN], visited[MAXN] = {0};
    int queue[MAXN], front = 0, rear = 0;
    for (int i = 0; i < g->n; i++) prev[i] = -1;
    queue[rear++] = x; visited[x] = 1;
    while (front < rear) {
        int u = queue[front++];
        if (u == y) break;
        for (int v = 0; v < g->n; v++)
            if (g->adj[u][v] && !visited[v]) { visited[v] = 1; prev[v] = u; queue[rear++] = v; }
    }
    if (!visited[y]) return -1;
    int len = 0, cur = y, tmp[MAXN];
    while (cur != -1) { tmp[len++] = cur; cur = prev[cur]; }
    for (int i = 0; i < len; i++) path[i] = tmp[len - 1 - i];
    return len;
}

void reportKnow(DiGraph *g, int x, int y) {
    int path[MAXN];
    int len = bfsDirected(g, x, y, path);
    if (len == -1) {
        printf("Sinh vien %d KHONG THE biet nha sinh vien %d (khong co duong di).\n", x, y);
        return;
    }
    if (g->adj[x][y]) {
        printf("Sinh vien %d biet nha sinh vien %d TRUC TIEP.\n", x, y);
    } else {
        printf("Sinh vien %d biet nha sinh vien %d, phai hoi it nhat %d sinh vien trung gian: ",
               x, y, len - 2);
        for (int i = 1; i < len - 1; i++) printf("%d ", path[i]);
        printf("\n");
    }
}

/* ===================== MAIN ===================== */
int main() {
    printf("========== CAU 1: CAY BST SO NGUYEN ==========\n");
    /*
       Cay theo hinh trong de:
                    8
              3            10
           1     6            14
                4   7             15
    */
    BSTNode *n8  = newIntNode(8);
    BSTNode *n3  = newIntNode(3);
    BSTNode *n10 = newIntNode(10);
    BSTNode *n1  = newIntNode(1);
    BSTNode *n6  = newIntNode(6);
    BSTNode *n14 = newIntNode(14);
    BSTNode *n4  = newIntNode(4);
    BSTNode *n7  = newIntNode(7);
    BSTNode *n15 = newIntNode(15);

    n8->left = n3;   n8->right = n10;
    n3->left = n1;   n3->right = n6;
    n10->right = n14;
    n6->left = n4;   n6->right = n7;
    n14->right = n15;

    printf("Tong cac so chan trong cay: %d\n", sumEven(n8));
    printf("Cap cua so 6 trong cay: %d\n", levelOf(n8, 6, 1));

    freeIntTree(n8);

    printf("\n========== CAU 2: DO THI BIET NHA (CO HUONG) ==========\n");
    DiGraph g;
    initDiGraph(&g, 9); /* gia su sinh vien 0..8 - KIEM TRA LAI SO SINH VIEN THUC TE TRONG DE */

    /* !!! DANH SACH CANH DUOI DAY LA PHUC DUNG TAM THOI TU ANH CHUP,
       HAY DOI CHIEU LAI VOI HINH VE THAT TRONG DE VA SUA CHO DUNG !!! */
    addDirectedEdge(&g, 5, 2);
    addDirectedEdge(&g, 5, 6);
    addDirectedEdge(&g, 1, 7);
    addDirectedEdge(&g, 7, 6);
    addDirectedEdge(&g, 0, 7);
    addDirectedEdge(&g, 4, 7);
    addDirectedEdge(&g, 4, 8);
    addDirectedEdge(&g, 8, 7);
    addDirectedEdge(&g, 8, 3);
    addDirectedEdge(&g, 3, 0);

    directKnown(&g, 3);
    reportKnow(&g, 5, 8);

    return 0;
}
