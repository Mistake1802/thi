/*
 * DE SO 01 - Cau truc du lieu - HK2 2024-2025
 * Cau 1: Cay tim kiem nhi phan (BST) quan ly sach, khoa la SO TRANG
 * Cau 2: Do thi vo huong (danh sach ke) - tram kiem lam
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===================== CAU 1 ===================== */

typedef struct Book {
    char name[100];
    int pages;
} Book;

typedef struct BSTNode {
    Book data;
    struct BSTNode *left, *right;
} BSTNode;

BSTNode* newBook(const char *name, int pages) {
    BSTNode *n = (BSTNode*)malloc(sizeof(BSTNode));
    strcpy(n->data.name, name);
    n->data.pages = pages;
    n->left = n->right = NULL;
    return n;
}

/* b) them 1 cuon sach vao cay (khoa = so trang) */
BSTNode* insertBook(BSTNode *root, const char *name, int pages) {
    if (root == NULL) return newBook(name, pages);
    if (pages < root->data.pages)
        root->left = insertBook(root->left, name, pages);
    else if (pages > root->data.pages)
        root->right = insertBook(root->right, name, pages);
    else
        printf("[Canh bao] So trang %d da ton tai (%s), khong them trung khoa.\n",
               pages, root->data.name);
    return root;
}

/* c) liet ke sach < 200 trang hoac > 400 trang */
void listBooksOutOfRange(BSTNode *root) {
    if (root == NULL) return;
    listBooksOutOfRange(root->left);
    if (root->data.pages < 200 || root->data.pages > 400)
        printf("  - %s (%d trang)\n", root->data.name, root->data.pages);
    listBooksOutOfRange(root->right);
}

/* d) kiem tra sach ten x co ton tai trong cay
   (phai duyet toan cay vi khoa cua BST la so trang, khong phai ten sach) */
int existsBookName(BSTNode *root, const char *name) {
    if (root == NULL) return 0;
    if (strcmp(root->data.name, name) == 0) return 1;
    return existsBookName(root->left, name) || existsBookName(root->right, name);
}

void freeBookTree(BSTNode *root) {
    if (!root) return;
    freeBookTree(root->left);
    freeBookTree(root->right);
    free(root);
}

/* ===================== CAU 2 ===================== */

#define MAXN 100

typedef struct {
    int n;
    int adj[MAXN][MAXN]; /* adj[i][j]=1 neu tram i,j noi truc tiep */
    int deg[MAXN];
} Graph;

void initGraph(Graph *g, int n) {
    g->n = n;
    memset(g->adj, 0, sizeof(g->adj));
    memset(g->deg, 0, sizeof(g->deg));
}

void addEdge(Graph *g, int u, int v) {
    if (!g->adj[u][v]) {
        g->adj[u][v] = g->adj[v][u] = 1;
        g->deg[u]++;
        g->deg[v]++;
    }
}

/* b) tram k noi truc tiep voi bao nhieu tram, la nhung tram nao */
void directNeighbors(Graph *g, int k) {
    printf("Tram %d noi truc tiep voi %d tram: ", k, g->deg[k]);
    for (int i = 0; i < g->n; i++)
        if (g->adj[k][i]) printf("%d ", i);
    printf("\n");
}

/* BFS tim duong di ngan nhat giua x va y, tra ve so dinh tren duong (ke ca x,y) */
int bfsPath(Graph *g, int x, int y, int path[]) {
    int prev[MAXN], visited[MAXN] = {0};
    int queue[MAXN], front = 0, rear = 0;
    for (int i = 0; i < g->n; i++) prev[i] = -1;
    queue[rear++] = x; visited[x] = 1;
    while (front < rear) {
        int u = queue[front++];
        if (u == y) break;
        for (int v = 0; v < g->n; v++) {
            if (g->adj[u][v] && !visited[v]) {
                visited[v] = 1;
                prev[v] = u;
                queue[rear++] = v;
            }
        }
    }
    if (!visited[y]) return -1;
    int len = 0, cur = y, tmp[MAXN];
    while (cur != -1) { tmp[len++] = cur; cur = prev[cur]; }
    for (int i = 0; i < len; i++) path[i] = tmp[len - 1 - i];
    return len;
}

/* c) tram x noi voi tram y phai qua it nhat bao nhieu tram trung gian, la tram nao */
void reportConnection(Graph *g, int x, int y) {
    int path[MAXN];
    int len = bfsPath(g, x, y, path);
    if (len == -1) {
        printf("Tram %d va tram %d khong co duong ket noi.\n", x, y);
        return;
    }
    if (g->adj[x][y]) {
        printf("Tram %d va tram %d noi TRUC TIEP voi nhau.\n", x, y);
    } else {
        printf("Tram %d va tram %d phai qua %d tram trung gian: ", x, y, len - 2);
        for (int i = 1; i < len - 1; i++) printf("%d ", path[i]);
        printf("\n");
    }
}

/* d) so cum ket noi, moi cum gom nhung tram nao */
void connectedComponents(Graph *g) {
    int visited[MAXN] = {0};
    int comp = 0;
    for (int s = 0; s < g->n; s++) {
        if (visited[s]) continue;
        comp++;
        int queue[MAXN], front = 0, rear = 0;
        queue[rear++] = s; visited[s] = 1;
        printf("Cum %d: %d ", comp, s);
        while (front < rear) {
            int u = queue[front++];
            for (int v = 0; v < g->n; v++) {
                if (g->adj[u][v] && !visited[v]) {
                    visited[v] = 1;
                    printf("%d ", v);
                    queue[rear++] = v;
                }
            }
        }
        printf("\n");
    }
    printf("Tong so cum ket noi: %d\n", comp);
}

/* ===================== MAIN ===================== */

int main() {
    printf("========== CAU 1: CAY SACH ==========\n");
    BSTNode *root = NULL;
    root = insertBook(root, "CTDL va GT", 450);
    root = insertBook(root, "LTCB", 300);
    root = insertBook(root, "LTHDT", 500);
    root = insertBook(root, "Cam nang lap trinh", 250);
    root = insertBook(root, "LTW", 320);

    printf("Cac cuon sach co duoi 200 trang hoac tren 400 trang:\n");
    listBooksOutOfRange(root);

    char bookName[100];
    printf("\nNhap ten cuon sach can kiem tra: ");
    fgets(bookName, sizeof(bookName), stdin);
    bookName[strcspn(bookName, "\n")] = 0;
    if (existsBookName(root, bookName))
        printf("=> Cuon sach \"%s\" CO trong cay.\n", bookName);
    else
        printf("=> Cuon sach \"%s\" KHONG co trong cay.\n", bookName);

    freeBookTree(root);

    printf("\n========== CAU 2: DO THI TRAM KIEM LAM ==========\n");
    Graph g;
    initGraph(&g, 7);
    /* 0:[1,3] 1:[0,2,4] 2:[1] 3:[0,5] 4:[1,6] 5:[3,6] 6:[4,5] */
    addEdge(&g, 0, 1); addEdge(&g, 0, 3);
    addEdge(&g, 1, 2); addEdge(&g, 1, 4);
    addEdge(&g, 3, 5);
    addEdge(&g, 4, 6);
    addEdge(&g, 5, 6);

    directNeighbors(&g, 2);
    reportConnection(&g, 1, 5);
    connectedComponents(&g);

    return 0;
}
