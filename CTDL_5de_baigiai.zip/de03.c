/*
 * DE SO 03 - Cau truc du lieu - HK2 2024-2025
 * Cau 1: Cay tong quat - phan loai dong vat
 * Cau 2: Do thi vo huong (MA TRAN KE) - tram sac xe dien
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===================== CAU 1 ===================== */
typedef struct TreeNode {
    char name[100];
    int weight; /* kg trung binh; 0 = nhom phan loai, chua phai 1 loai cu the */
    struct TreeNode *firstChild;
    struct TreeNode *nextSibling;
} TreeNode;

TreeNode* newNode(const char *name, int weight) {
    TreeNode *n = (TreeNode*)malloc(sizeof(TreeNode));
    strcpy(n->name, name);
    n->weight = weight;
    n->firstChild = n->nextSibling = NULL;
    return n;
}
TreeNode* findNode(TreeNode *root, const char *name) {
    if (root == NULL) return NULL;
    if (strcmp(root->name, name) == 0) return root;
    TreeNode *f = findNode(root->firstChild, name);
    if (f) return f;
    return findNode(root->nextSibling, name);
}
/* b) them 1 loai dong vat la con cua loai (nhom) ten x */
int addSpecies(TreeNode *root, const char *parentName, const char *name, int weight) {
    TreeNode *parent = findNode(root, parentName);
    if (!parent) return 0;
    TreeNode *child = newNode(name, weight);
    if (!parent->firstChild) parent->firstChild = child;
    else {
        TreeNode *cur = parent->firstChild;
        while (cur->nextSibling) cur = cur->nextSibling;
        cur->nextSibling = child;
    }
    return 1;
}
/* c) kiem tra loai ten x co ton tai trong cay */
int existsSpecies(TreeNode *root, const char *name) {
    return findNode(root, name) != NULL;
}
/* d) liet ke loai co can nang TB duoi 50kg hoac tren 200kg
   (chi xet node co weight>0, tuc la loai thuc su, bo qua nhom phan loai) */
void listByWeight(TreeNode *root) {
    if (!root) return;
    if (root->weight > 0 && (root->weight < 50 || root->weight > 200))
        printf("  - %s (%d kg)\n", root->name, root->weight);
    listByWeight(root->firstChild);
    listByWeight(root->nextSibling);
}
void freeTree(TreeNode *root) {
    if (!root) return;
    freeTree(root->firstChild);
    freeTree(root->nextSibling);
    free(root);
}

/* ===================== CAU 2 (ma tran ke) ===================== */
#define MAXN 100
typedef struct {
    int n;
    int m[MAXN][MAXN];
} MGraph;

void initMGraph(MGraph *g, int n) { g->n = n; memset(g->m, 0, sizeof(g->m)); }

/* b) tram k noi truc tiep voi bao nhieu tram khac, la tram nao */
void directNeighborsM(MGraph *g, int k) {
    int cnt = 0;
    for (int i = 0; i < g->n; i++) if (g->m[k][i]) cnt++;
    printf("Tram %d noi truc tiep voi %d tram: ", k, cnt);
    for (int i = 0; i < g->n; i++) if (g->m[k][i]) printf("%d ", i);
    printf("\n");
}
int bfsPathM(MGraph *g, int x, int y, int path[]) {
    int prev[MAXN], visited[MAXN] = {0};
    int queue[MAXN], front=0, rear=0;
    for (int i=0;i<g->n;i++) prev[i]=-1;
    queue[rear++]=x; visited[x]=1;
    while(front<rear){
        int u=queue[front++];
        if (u==y) break;
        for (int v=0; v<g->n; v++)
            if (g->m[u][v] && !visited[v]) { visited[v]=1; prev[v]=u; queue[rear++]=v; }
    }
    if (!visited[y]) return -1;
    int len=0, cur=y, tmp[MAXN];
    while (cur!=-1){ tmp[len++]=cur; cur=prev[cur]; }
    for (int i=0;i<len;i++) path[i]=tmp[len-1-i];
    return len;
}
/* c) tram x noi voi tram y phai qua it nhat bao nhieu tram trung gian, la tram nao */
void reportConnectionM(MGraph *g, int x, int y) {
    int path[MAXN];
    int len = bfsPathM(g,x,y,path);
    if (len==-1) { printf("Tram %d va tram %d khong ket noi.\n", x, y); return; }
    if (g->m[x][y]) printf("Tram %d va tram %d noi TRUC TIEP.\n", x, y);
    else {
        printf("Tram %d va tram %d phai qua %d tram trung gian: ", x, y, len-2);
        for (int i=1;i<len-1;i++) printf("%d ", path[i]);
        printf("\n");
    }
}
/* d) so cum ket noi, moi cum gom nhung tram nao */
void connectedComponentsM(MGraph *g) {
    int visited[MAXN]={0}, comp=0;
    for (int s=0; s<g->n; s++) {
        if (visited[s]) continue;
        comp++;
        int queue[MAXN], front=0, rear=0;
        queue[rear++]=s; visited[s]=1;
        printf("Cum %d: %d ", comp, s);
        while (front<rear) {
            int u=queue[front++];
            for (int v=0; v<g->n; v++)
                if (g->m[u][v] && !visited[v]) { visited[v]=1; printf("%d ", v); queue[rear++]=v; }
        }
        printf("\n");
    }
    printf("Tong so cum ket noi: %d\n", comp);
}

/* ===================== MAIN ===================== */
int main() {
    printf("========== CAU 1: CAY PHAN LOAI DONG VAT ==========\n");
    /*
       Animals(0)
        |- Mammals(0) -- Tiger(190)
        |- Birds(0)
        |- Reptiles(0) -- Monkey(40)
       (Luu y: anh chup khong the hien ro Monkey la con cua nhom nao,
        ban doi chieu lai voi de goc, neu can chi can doi lai 1 dong gan nhau)
    */
    TreeNode *root = newNode("Animals", 0);
    TreeNode *mammals = newNode("Mammals", 0);
    TreeNode *birds = newNode("Birds", 0);
    TreeNode *reptiles = newNode("Reptiles", 0);
    root->firstChild = mammals;
    mammals->nextSibling = birds;
    birds->nextSibling = reptiles;
    mammals->firstChild = newNode("Tiger", 190);
    reptiles->firstChild = newNode("Monkey", 40);

    char qName[100];
    printf("Nhap ten loai dong vat can kiem tra: ");
    fgets(qName, sizeof(qName), stdin);
    qName[strcspn(qName, "\n")] = 0;
    if (existsSpecies(root, qName))
        printf("=> \"%s\" CO trong cay.\n", qName);
    else
        printf("=> \"%s\" KHONG co trong cay.\n", qName);

    printf("Cac loai co can nang TB duoi 50kg hoac tren 200kg:\n");
    listByWeight(root);

    freeTree(root);

    printf("\n========== CAU 2: TRAM SAC XE DIEN (MA TRAN KE) ==========\n");
    MGraph g;
    initMGraph(&g, 7);
    int matrix[7][7] = {
        {0,1,1,0,0,1,0},
        {1,0,0,1,0,0,1},
        {1,0,0,0,1,0,1},
        {0,1,0,0,0,1,0},
        {0,0,1,0,0,0,1},
        {1,0,0,1,0,0,0},
        {0,1,1,0,1,0,0}
    };
    for (int i=0;i<7;i++) for (int j=0;j<7;j++) g.m[i][j]=matrix[i][j];

    directNeighborsM(&g, 1);
    reportConnectionM(&g, 0, 3);
    connectedComponentsM(&g);

    return 0;
}
