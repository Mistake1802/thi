/*
 * DE SO 04 - Cau truc du lieu - HK2 2024-2025
 * Cau 1: BST - hanh tinh, khoa la KHOANG CACH DEN MAT TROI
 * Cau 2: Do thi vo huong (danh sach ke) - ga tau thanh pho
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===================== CAU 1 ===================== */
typedef struct Planet {
    char name[100];
    int distance; /* trieu km */
} Planet;
typedef struct BSTNode {
    Planet data;
    struct BSTNode *left, *right;
} BSTNode;

BSTNode* newPlanet(const char *name, int dist) {
    BSTNode *n = (BSTNode*)malloc(sizeof(BSTNode));
    strcpy(n->data.name, name);
    n->data.distance = dist;
    n->left = n->right = NULL;
    return n;
}
/* b) them 1 hanh tinh vao cay (khoa = khoang cach) */
BSTNode* insertPlanet(BSTNode *root, const char *name, int dist) {
    if (!root) return newPlanet(name, dist);
    if (dist < root->data.distance) root->left = insertPlanet(root->left, name, dist);
    else if (dist > root->data.distance) root->right = insertPlanet(root->right, name, dist);
    else printf("[Canh bao] Khoang cach %d da ton tai.\n", dist);
    return root;
}
/* c) liet ke hanh tinh co khoang cach < 100 trieu km hoac > 500 trieu km */
void listPlanetsOutOfRange(BSTNode *root) {
    if (!root) return;
    listPlanetsOutOfRange(root->left);
    if (root->data.distance < 100 || root->data.distance > 500)
        printf("  - %s (%d trieu km)\n", root->data.name, root->data.distance);
    listPlanetsOutOfRange(root->right);
}
/* d) kiem tra hanh tinh ten x co ton tai (duyet toan cay vi khoa la khoang cach) */
int existsPlanetName(BSTNode *root, const char *name) {
    if (!root) return 0;
    if (strcmp(root->data.name, name) == 0) return 1;
    return existsPlanetName(root->left, name) || existsPlanetName(root->right, name);
}
void freePlanetTree(BSTNode *root) {
    if (!root) return;
    freePlanetTree(root->left);
    freePlanetTree(root->right);
    free(root);
}

/* ===================== CAU 2 ===================== */
#define MAXN 100
typedef struct {
    int n;
    int adj[MAXN][MAXN];
    int deg[MAXN];
} Graph;
void initGraph(Graph *g, int n) { g->n=n; memset(g->adj,0,sizeof(g->adj)); memset(g->deg,0,sizeof(g->deg)); }
void addEdge(Graph *g, int u, int v) {
    if (!g->adj[u][v]) { g->adj[u][v]=g->adj[v][u]=1; g->deg[u]++; g->deg[v]++; }
}
/* b) ga tau thu k noi truc tiep voi bao nhieu ga tau khac */
void directNeighbors(Graph *g, int k) {
    printf("Ga %d noi truc tiep voi %d ga: ", k, g->deg[k]);
    for (int i=0;i<g->n;i++) if (g->adj[k][i]) printf("%d ", i);
    printf("\n");
}
int bfsPath(Graph *g, int x, int y, int path[]) {
    int prev[MAXN], visited[MAXN]={0};
    int queue[MAXN], front=0, rear=0;
    for (int i=0;i<g->n;i++) prev[i]=-1;
    queue[rear++]=x; visited[x]=1;
    while (front<rear) {
        int u=queue[front++];
        if (u==y) break;
        for (int v=0;v<g->n;v++)
            if (g->adj[u][v] && !visited[v]) { visited[v]=1; prev[v]=u; queue[rear++]=v; }
    }
    if (!visited[y]) return -1;
    int len=0, cur=y, tmp[MAXN];
    while (cur!=-1) { tmp[len++]=cur; cur=prev[cur]; }
    for (int i=0;i<len;i++) path[i]=tmp[len-1-i];
    return len;
}
/* c) ga x noi voi ga y phai qua it nhat bao nhieu ga trung gian, la ga nao */
void reportConnection(Graph *g, int x, int y) {
    int path[MAXN];
    int len = bfsPath(g,x,y,path);
    if (len==-1) { printf("Ga %d va ga %d khong ket noi.\n", x, y); return; }
    if (g->adj[x][y]) printf("Ga %d va ga %d noi TRUC TIEP.\n", x, y);
    else {
        printf("Ga %d va ga %d phai qua %d ga trung gian: ", x, y, len-2);
        for (int i=1;i<len-1;i++) printf("%d ", path[i]);
        printf("\n");
    }
}
/* d) thanh pho co bao nhieu cum ket noi, moi cum gom nhung ga nao */
void connectedComponents(Graph *g) {
    int visited[MAXN]={0}, comp=0;
    for (int s=0;s<g->n;s++) {
        if (visited[s]) continue;
        comp++;
        int queue[MAXN], front=0, rear=0;
        queue[rear++]=s; visited[s]=1;
        printf("Cum %d: %d ", comp, s);
        while (front<rear) {
            int u=queue[front++];
            for (int v=0;v<g->n;v++)
                if (g->adj[u][v] && !visited[v]) { visited[v]=1; printf("%d ", v); queue[rear++]=v; }
        }
        printf("\n");
    }
    printf("Tong so cum ket noi: %d\n", comp);
}

/* ===================== MAIN ===================== */
int main() {
    printf("========== CAU 1: CAY HANH TINH ==========\n");
    BSTNode *root = NULL;
    root = insertPlanet(root, "Sao Thuy", 57);
    root = insertPlanet(root, "Sao Kim", 108);
    root = insertPlanet(root, "Trai Dat", 149);
    root = insertPlanet(root, "Sao Hoa", 227);
    root = insertPlanet(root, "Sao Moc", 778);

    printf("Cac hanh tinh co khoang cach < 100 trieu km hoac > 500 trieu km:\n");
    listPlanetsOutOfRange(root);

    if (existsPlanetName(root, "Sao Tho"))
        printf("Sao Tho CO trong cay.\n");
    else
        printf("Sao Tho KHONG co trong cay.\n");

    freePlanetTree(root);

    printf("\n========== CAU 2: GA TAU THANH PHO ==========\n");
    Graph g;
    initGraph(&g, 7);
    /* 0:[1,4] 1:[0,2,5] 2:[1,3,6] 3:[2,4] 4:[0,3,5] 5:[1,4,6] 6:[2,5] */
    addEdge(&g,0,1); addEdge(&g,0,4);
    addEdge(&g,1,2); addEdge(&g,1,5);
    addEdge(&g,2,3); addEdge(&g,2,6);
    addEdge(&g,3,4);
    addEdge(&g,4,5);
    addEdge(&g,5,6);

    directNeighbors(&g, 2);
    reportConnection(&g, 5, 2);
    connectedComponents(&g);

    return 0;
}
